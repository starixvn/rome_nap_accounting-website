﻿using System;
using System.Web.UI;

public partial class BA_LatestBet : PageBase 
{
    
    protected void Page_Load(object sender, EventArgs e)
    {
       
    }

}