﻿using System;
using System.Web.UI;
using System.Web.UI.WebControls;


    /// <summary>
    /// Summary description for ReportMasterPageBase
    /// </summary>
    public class ReportMasterPageBase : MasterPage
    {
        public virtual ImageButton ExportButton
        {
            get { throw new NotImplementedException(); }
            set { throw new NotImplementedException(); }
        }
    }
