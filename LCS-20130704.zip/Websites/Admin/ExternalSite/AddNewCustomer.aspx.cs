﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Admin_ExternalSite_AddNewCustomer : PageBase
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }
}