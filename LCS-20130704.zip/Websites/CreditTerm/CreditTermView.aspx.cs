using System;
using System.Data;
using System.Web;
using System.Text;
using Sunplus.Accounting.Business.CacheManager;
using Sunplus.Accounting.Core.Common;
using Sunplus.Accounting.Core.Extensions;
using Sunplus.Accounting.Core.Helper;
using Sunplus.Accounting.Core.Web;
using Sunplus.Core.LoggingLib;
using IBCUtils.Web;
using Sunplus.Accounting.DataAccess.IBCDLL.Accounting;
using IBCUtils;
using DNAide.Data;
using DNAide.Core;
using DNAide.Web;



/// <summary>
/// CITS
/// </summary>
public partial class CreditTerm_CreditTermView : PageBase
{
    
    public string script = "";
    public string msg = "";
    protected void Page_Load(object sender, EventArgs e)
    {
        Response.Cache.SetCacheability(HttpCacheability.NoCache);
        content.Text = getcontent();
    }
    string getcontent()
    {
        StringBuilder html = new StringBuilder();
        try
        {
            string  form = Sunplus.Accounting.Core.Web.WebUtils.LoadTemplate("CreditTeam/CreditTermViewForm.htm");
            int custid = Convert.ToInt32(Session["CustId"]);
            int userid = Convert.ToInt32(Session["AccId"]);
            if (!string.IsNullOrEmpty(Request["btnsubmit"]))
            {
                if (custid != 0 && userid != 0)
                {
                    string creditgrade = Request["cbograde"];
                    double preagreeamount = 0, installmentamount = 0;
                    if (string.IsNullOrEmpty(Request["txtPreAmt"]) || string.IsNullOrEmpty(Request["txtInsAmt"]))
                        msg=AlertMessage.GetMsg("Invalid format number.",AlertMessage.MsgType.Error);
                    else if (!IBCUtils.Validator.isNumber(Request["txtPreAmt"]) || !IBCUtils.Validator.isNumber(Request["txtInsAmt"]))
                        msg = AlertMessage.GetMsg("Invalid format number.", AlertMessage.MsgType.Error);
                    else
                    {
                        preagreeamount = Convert.ToDouble(Request["txtPreAmt"]);
                        installmentamount = Convert.ToDouble(Request["txtInsAmt"]);
                        string installmentdate = Request["day"];
                        string accountremark = Request["remark"];
                        int groupid = Convert.ToInt32(Request["cbogroup"]);
                        int IsGroupHeadline = 0; if (!string.IsNullOrEmpty(Request["groupheadline"])) IsGroupHeadline = 1;
                        int checkerid = CastAide.AsInt32(Request["ddlCheckerList"], 0);
                        var rs = AccountCredit.Acc_CreditTermUpdCustomer(custid, creditgrade, preagreeamount, installmentamount, installmentdate, accountremark, groupid, IsGroupHeadline, userid, checkerid);
                        msg=AlertMessage.GetMsg(rs.ErrorMessage, AlertMessage.MsgType.Success);
                        System.Threading.Thread.Sleep(2000);
                    }
                }
                else msg="";
            }
            else msg="";
            
            DataTable dt = AccountCredit.Acc_CreditTermSelByCustID(custid).ResultSet.Tables[0];
            foreach (DataRow dr in dt.Rows)
            {
                TemplateHandler.Assign(ref form, "{customer}", Convert.ToString(dr["username"]));
                DataTable dtGroup = AccountCredit.Acc_CreditTermSelGroupHeadline().ResultSet.Tables[0];
                StringBuilder strGroup = new StringBuilder();
                strGroup.Append("<option value='0'>0 Not assign group</option>");                
                foreach(DataRow drGroup in dtGroup.Rows)
                {                    
                    string option = "<option value='" + drGroup["groupid"] + "'";
                    option += (drGroup["groupid"].ToString() == dr["groupid"].ToString()) ? " selected " : "";
                    option += ">" + drGroup["username"] + "</option>";
                    strGroup.Append(option);
                }
                TemplateHandler.Assign(ref form, "{listgroup}", strGroup.ToString());
                TemplateHandler.Assign(ref form, "{listgrade}", setoption(Convert.ToString(dr["creditgrade"])));

                string isgroupheadline = "", disabledChecker = "";

                if (CastAide.AsBoolean(dr["isgroupheadline"]))
                    isgroupheadline = "checked";
                else
                    disabledChecker = "disabled";

                TemplateHandler.Assign(ref form, "{checked}", isgroupheadline);
                TemplateHandler.Assign(ref form, "{disabled}", disabledChecker);

                TemplateHandler.Assign(ref form, "{PreAmt}", FormatHandler.FormatNumber2(dr["preagreeamount"]));
                TemplateHandler.Assign(ref form, "{InsAmt}", FormatHandler.FormatNumber2(dr["installmentamount"]));
                TemplateHandler.Assign(ref form, "{curr}", CacheUtils.GetExchangeName(DNAide.Core.CastAide.AsInt32((dr["curr"]))));
                TemplateHandler.Assign(ref form, "{listday}", setInsDay(Convert.ToInt32(dr["intinday"])));
                TemplateHandler.Assign(ref form, "{remark}", Convert.ToString(dr["accountremark"]));
                string checkerid = CastAide.AsString(dr["checkerid"], "");
                TemplateHandler.Assign(ref form, "{ddlCheckerList}", CheckerList(checkerid, disabledChecker));
            }
            if (custid == 0 || userid == 0) html.Append(AlertMessage.GetMsg("Session is expired, please re log-in ", AlertMessage.MsgType.Error));
            else html.Append(form);
        }
        catch (Exception ex) 
        {
            LogExtensions.ExceptionHandler(ex);
        }
        return html.ToString();
    }

    #region string setoption(string value)
    string setoption(string value)
    {
        string str = "";
        str += "<option value='A'"; str += (value == "A") ? " selected ": ""; str += ">A</ontion>";
        str += "<option value='B'"; str += (value == "B") ? " selected " : ""; str += ">B</ontion>";
        str += "<option value='C'"; str += (value == "C") ? " selected " : ""; str += ">C</ontion>";
        str += "<option value='D'"; str += (value == "D") ? " selected " : ""; str += ">D</ontion>";
        str += "<option value='E'"; str += (value == "E") ? " selected " : ""; str += ">E</ontion>";
        str += "<option value='F'"; str += (value == "F") ? " selected " : ""; str += ">F</ontion>";
        return str;
    }
    #endregion

    #region  setInsDay(int value)
    string setInsDay(int value)
    {
        string str = "";
        for(int i = 1; i<=31; i++)
        {
            str += "<option value='"+ i +"'"; str += (value == i)? " selected ": ""; str += ">" + i + "</option>";
        }
        return str;
    }
    #endregion

    #region CheckerList
    string CheckerList(string CheckerId , string disabledChecker)
    {
        string str = "<select " + disabledChecker + " id='ddlCheckerList' name='ddlCheckerList'>";
        DbResult rs = AccountCredit.Acc_CreditTermSelCheckerList();
        DataTable dt = rs.ResultSet.Tables[0];

        str += "<option value='0'>---</option>";

        foreach (DataRow dr in dt.Rows)
        {
            if(CheckerId.Equals(dr["custid"].ToString()))
                str += "<option selected='true' value='"+ dr["custid"] +"'>"+ dr["username"] +"</option>";
            else
                str += "<option value='" + dr["custid"] + "'>" + dr["username"] + "</option>";
        }

        str += "</select>";

        script += "<script type='text/javascript'>";
        script += "var checkerid='" + CheckerId + "';";
        script += "</script>";
        Response.Write(script);

        return str;
    }
    #endregion
}
