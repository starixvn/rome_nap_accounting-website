﻿using System;

public partial class BetList_BetListNumberGameResult : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }
}
