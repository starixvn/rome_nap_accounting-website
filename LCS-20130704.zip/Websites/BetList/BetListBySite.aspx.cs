﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Collections;
using DNAide.Core;
using Sunplus.Accounting.Business.BetList;
using Sunplus.Accounting.Business.Report;

public partial class BetList_BetListBySite : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        Response.Cache.SetCacheability(HttpCacheability.NoCache);

        this.ReportTitle.Text = Reports.Title;
        var betlist = new BetListBySite();

        Hashtable hash = new Hashtable();
        hash.Add("custid", CastAide.AsString(Request["custid"]));
        hash.Add("username", CastAide.AsString(Request["username"]));
        hash.Add("fdate", CastAide.AsString(Request["fdate"]));
        hash.Add("tdate", CastAide.AsString(Request["tdate"]));
        hash.Add("showsb", CastAide.AsString(Request["showSB"]));
        hash.Add("showhr", CastAide.AsString(Request["showHR"]));
        hash.Add("basecurrency", CastAide.AsString(Request["baseCurrency"]));
        hash.Add("site", CastAide.AsString(Request["site"]));

        this.reportContent.Text = betlist.RenderHTML(hash);
    }
}