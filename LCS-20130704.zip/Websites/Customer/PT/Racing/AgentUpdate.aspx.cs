﻿using System;

public partial class Customer_Racing_AgentUpdate : RacingPage
{
    protected void Page_Load(object sender, EventArgs e)
    {
    }
}
