﻿using System;

public partial class Customer_Racing_AgentMinMaxUpdate : RacingPage
{
    protected void Page_Load(object sender, EventArgs e)
    {
        
    }
}
