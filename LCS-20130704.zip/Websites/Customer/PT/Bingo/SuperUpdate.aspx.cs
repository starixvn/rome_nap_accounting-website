﻿using System;

public partial class Customer_Bingo_SuperUpdate : PageBase
{
    protected void Page_Load(object sender, EventArgs e)
    {
    }
}
