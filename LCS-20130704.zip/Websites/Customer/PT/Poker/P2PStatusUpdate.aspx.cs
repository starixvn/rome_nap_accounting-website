﻿using System;

public partial class Customer_Poker_P2PStatusUpdate : P2PPage
{
    protected void Page_Load(object sender, EventArgs e)
    {
    }
}
