﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Customer_PT_Poker_AgentUpdate : P2PPage
{
    protected void Page_Load(object sender, EventArgs e)
    {
        roleId = "2";
        
    }
}